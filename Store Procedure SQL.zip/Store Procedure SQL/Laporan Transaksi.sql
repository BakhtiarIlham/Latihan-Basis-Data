DELIMITER //
CREATE PROCEDURE laporan_transaksi (
    IN p_tanggal_awal DATE,
    IN p_tanggal_akhir DATE
)
BEGIN
    SELECT t.id_transaksi, p.nama AS nama_pelanggan, t.tanggal, t.total
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
    WHERE t.tanggal BETWEEN p_tanggal_awal AND p_tanggal_akhir
    ORDER BY t.tanggal;
END //
DELIMITER ;

CALL laporan_transaksi('2025-10-01', '2025-10-31');

