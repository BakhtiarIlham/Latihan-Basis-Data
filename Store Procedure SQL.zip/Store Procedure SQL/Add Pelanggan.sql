DELIMITER //
CREATE PROCEDURE tambah_pelanggan (
    IN p_nama VARCHAR(100),
    IN p_email VARCHAR(100),
    IN p_no_hp VARCHAR(15),
    IN p_alamat TEXT
)
BEGIN
    INSERT INTO pelanggan (nama, email, no_hp, alamat)
    VALUES (p_nama, p_email, p_no_hp, p_alamat);
END //
DELIMITER ;

CALL tambah_pelanggan('Dewi', 'dewi@gmail.com', '08135555555', 'Bandung');

