-- 1) Ringkasan aduan dengan info pelapor, kategori, penugas
CREATE VIEW vw_aduan_detail AS
SELECT a.aduan_id, a.judul, a.deskripsi, a.lokasi, a.status, a.tanggal_lapor, a.tanggal_diterima, a.tanggal_selesai,
       w.warga_id, w.nama AS pelapor, k.kategori_id, k.nama_kategori,
       ap.admin_id, ap.nama AS admin_nama,
       p.petugas_id, p.nama AS petugas_nama
FROM aduan a
LEFT JOIN warga w ON a.warga_id = w.warga_id
LEFT JOIN kategori_aduan k ON a.kategori_id = k.kategori_id
LEFT JOIN admin_pemda ap ON a.admin_id = ap.admin_id
LEFT JOIN petugas p ON a.petugas_id = p.petugas_id;

-- 2) Statistik: jumlah per kategori
CREATE VIEW vw_jumlah_per_kategori AS
SELECT COALESCE(k.nama_kategori,'(Lainnya)') AS kategori, COUNT(a.aduan_id) AS jumlah
FROM aduan a
LEFT JOIN kategori_aduan k ON a.kategori_id = k.kategori_id
GROUP BY k.nama_kategori;

-- 3) Rata-rata waktu penyelesaian (jam)
CREATE VIEW vw_avg_waktu_selesai AS
SELECT AVG(TIMESTAMPDIFF(HOUR, tanggal_lapor, tanggal_selesai)) AS avg_hours
FROM aduan WHERE tanggal_selesai IS NOT NULL;