DELIMITER //
CREATE PROCEDURE hapus_produk (
    IN p_id_produk INT
)
BEGIN
    DELETE FROM produk WHERE id_produk = p_id_produk;
END //
DELIMITER ;
