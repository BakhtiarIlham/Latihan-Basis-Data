-- Warga (id 2) membuat aduan
INSERT INTO aduan (warga_id, kategori_id, judul, deskripsi, lokasi)
VALUES (2, 4, 'Lampu jalan mati', 'Lampu mati sejak seminggu', 'Jl. Kenanga - dekat taman');

-- Ambil id baru (di Workbench gunakan LAST_INSERT_ID() atau lihat select)
SELECT LAST_INSERT_ID() AS new_aduan_id;

-- Simpan lampiran foto (mis new_aduan_id = 2)
INSERT INTO lampiran (aduan_id, uploaded_by_type, uploaded_by_id, file_path, tipe)
VALUES (2, 'WARGA', 2, '/uploads/lampu_kenanga_01.jpg', 'FOTO');

------------------------------------------------------------------------------------

-- Lihat aduan yang belum pernah ditugaskan
SELECT a.aduan_id, a.judul, w.nama AS pelapor, k.nama_kategori
FROM aduan a
LEFT JOIN tugas_penindakan t ON a.aduan_id = t.aduan_id
JOIN warga w ON a.warga_id = w.warga_id
LEFT JOIN kategori_aduan k ON a.kategori_id = k.kategori_id
WHERE t.tugas_id IS NULL;

-- Assign (mis: assign aduan_id=2 ke petugas_id=2 oleh admin_id=1)
INSERT INTO tugas_penindakan (aduan_id, petugas_id, assigned_by, catatan)
VALUES (2, 2, 1, 'Periksa lampu & ganti bohlam bila perlu');

-- Trigger akan otomatis update aduan.status -> 'DIPROSES' dan menambahkan notifikasi ke petugas

------------------------------------------------------------------------------------

-- Petugas melihat tugasnya (petugas_id = 2)
SELECT t.tugas_id, t.aduan_id, a.judul, a.lokasi, t.status_tugas
FROM tugas_penindakan t
JOIN aduan a ON t.aduan_id = a.aduan_id
WHERE t.petugas_id = 2;

-- Petugas menyelesaikan tugas: gunakan transaksi
START TRANSACTION;
UPDATE tugas_penindakan SET status_tugas = 'SELESAI', catatan = CONCAT(IFNULL(catatan,''), '\nSelesai pada ', NOW())
WHERE tugas_id =  (SELECT tugas_id FROM tugas_penindakan WHERE aduan_id = 2 AND petugas_id = 2 ORDER BY tanggal_assign DESC LIMIT 1);

-- Update aduan menjadi SELESAI (trigger akan set tanggal_selesai & notifikasi ke warga)
UPDATE aduan SET status = 'SELESAI' WHERE aduan_id = 2;
-- Upload bukti pekerjaan (hubungkan ke tugas_id)
INSERT INTO lampiran (aduan_id, tugas_id, uploaded_by_type, uploaded_by_id, file_path, tipe)
VALUES (2, (SELECT tugas_id FROM tugas_penindakan WHERE aduan_id = 2 AND petugas_id = 2 ORDER BY tanggal_assign DESC LIMIT 1),
        'PETUGAS', 2, '/uploads/bukti_lampu_kenanga_01.jpg', 'BUKTI');
COMMIT;

------------------------------------------------------------------------------------

-- Lihat notifikasi warga (warga_id=2)
SELECT * FROM notifikasi WHERE recipient_type='WARGA' AND recipient_id = 2 ORDER BY created_at DESC;

-- Lihat riwayat status aduan (log)
SELECT * FROM log_status WHERE aduan_id = 2 ORDER BY tanggal_ubah;



