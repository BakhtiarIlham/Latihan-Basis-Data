DELIMITER //
CREATE PROCEDURE tambah_transaksi (
    IN p_id_pelanggan INT,
    IN p_tanggal DATE,
    IN p_id_produk INT,
    IN p_jumlah INT
)
BEGIN
    DECLARE v_harga DECIMAL(10,2);
    DECLARE v_total DECIMAL(10,2);
    
    -- Ambil harga produk
    SELECT harga INTO v_harga FROM produk WHERE id_produk = p_id_produk;
    SET v_total = v_harga * p_jumlah;

    -- Masukkan data ke tabel transaksi
    INSERT INTO transaksi (id_pelanggan, tanggal, total)
    VALUES (p_id_pelanggan, p_tanggal, v_total);

    -- Masukkan detail transaksi
    INSERT INTO detail_transaksi (id_transaksi, id_produk, jumlah, subtotal)
    VALUES (LAST_INSERT_ID(), p_id_produk, p_jumlah, v_total);

    -- Kurangi stok produk
    UPDATE produk SET stok = stok - p_jumlah WHERE id_produk = p_id_produk;
END //
DELIMITER ;

CALL tambah_transaksi(1, '2025-10-20', 2, 3);
