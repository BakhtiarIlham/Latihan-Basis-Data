CREATE DATABASE IF NOT EXISTS sistem_aduan_bintaro
  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
USE sistem_aduan_bintaro;

-- TABEL: warga (Citizen)
CREATE TABLE warga (
  warga_id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  no_hp VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- TABEL: admin (operator & manager, role membedakan)
CREATE TABLE admin_pemda (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  username VARCHAR(80) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('ADMIN','MANAGER') DEFAULT 'ADMIN',
  email VARCHAR(150),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- TABEL: petugas lapangan
CREATE TABLE petugas (
  petugas_id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  bidang VARCHAR(80), -- kebersihan/perhubungan/keamanan/dll
  no_hp VARCHAR(20),
  status_aktif BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- TABEL: kategori aduan (normalisasi kategori)
CREATE TABLE kategori_aduan (
  kategori_id INT AUTO_INCREMENT PRIMARY KEY,
  nama_kategori VARCHAR(100) UNIQUE NOT NULL,
  deskripsi TEXT
) ENGINE=InnoDB;

-- TABEL: aduan (inti)
CREATE TABLE aduan (
  aduan_id INT AUTO_INCREMENT PRIMARY KEY,
  warga_id INT NOT NULL,
  kategori_id INT,
  judul VARCHAR(200) NOT NULL,
  deskripsi TEXT,
  lokasi VARCHAR(255),
  status ENUM('BARU','DITERIMA','DIPROSES','SELESAI','DITOLAK') DEFAULT 'BARU',
  tanggal_lapor DATETIME DEFAULT CURRENT_TIMESTAMP,
  tanggal_diterima DATETIME NULL,
  tanggal_selesai DATETIME NULL,
  admin_id INT NULL,   -- admin yang menangani/menanggapi
  petugas_id INT NULL, -- petugas saat ini (mirip assignee)
  FOREIGN KEY (warga_id) REFERENCES warga(warga_id) ON DELETE CASCADE,
  FOREIGN KEY (kategori_id) REFERENCES kategori_aduan(kategori_id) ON DELETE SET NULL,
  FOREIGN KEY (admin_id) REFERENCES admin_pemda(admin_id) ON DELETE SET NULL,
  FOREIGN KEY (petugas_id) REFERENCES petugas(petugas_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- TABEL: tugas_penindakan (assignment/history of assignment)
CREATE TABLE tugas_penindakan (
  tugas_id INT AUTO_INCREMENT PRIMARY KEY,
  aduan_id INT NOT NULL,
  petugas_id INT NOT NULL,
  assigned_by INT NULL, -- admin_id yang assign
  status_tugas ENUM('DITUGASKAN','SEDANG_DIKERJAKAN','SELESAI','DIBATALKAN') DEFAULT 'DITUGASKAN',
  catatan TEXT,
  tanggal_assign DATETIME DEFAULT CURRENT_TIMESTAMP,
  tanggal_update DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (aduan_id) REFERENCES aduan(aduan_id) ON DELETE CASCADE,
  FOREIGN KEY (petugas_id) REFERENCES petugas(petugas_id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_by) REFERENCES admin_pemda(admin_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- TABEL: lampiran (file foto/video dari warga atau petugas)
CREATE TABLE lampiran (
  lampiran_id INT AUTO_INCREMENT PRIMARY KEY,
  aduan_id INT NOT NULL,
  tugas_id INT NULL, -- jika upload bukti setelah tugas selesai
  uploaded_by_type ENUM('WARGA','PETUGAS','ADMIN') DEFAULT 'WARGA',
  uploaded_by_id INT NULL,
  file_path VARCHAR(500) NOT NULL, -- simpan path/URL
  tipe ENUM('FOTO','VIDEO','BUKTI') DEFAULT 'FOTO',
  uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aduan_id) REFERENCES aduan(aduan_id) ON DELETE CASCADE,
  FOREIGN KEY (tugas_id) REFERENCES tugas_penindakan(tugas_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- TABEL: feedback (rating oleh warga)
CREATE TABLE feedback (
  feedback_id INT AUTO_INCREMENT PRIMARY KEY,
  aduan_id INT NOT NULL,
  rating TINYINT, -- 1..5
  komentar TEXT,
  tanggal_feedback DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aduan_id) REFERENCES aduan(aduan_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- TABEL: log_status (riwayat status untuk audit)
CREATE TABLE log_status (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  aduan_id INT NOT NULL,
  status_lama VARCHAR(30),
  status_baru VARCHAR(30),
  diubah_oleh VARCHAR(100), -- nama / system
  tanggal_ubah DATETIME DEFAULT CURRENT_TIMESTAMP,
  keterangan TEXT,
  FOREIGN KEY (aduan_id) REFERENCES aduan(aduan_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- TABEL: notifikasi (riwayat notifikasi yang dikirim)
CREATE TABLE notifikasi (
  notif_id INT AUTO_INCREMENT PRIMARY KEY,
  recipient_type ENUM('WARGA','PETUGAS','ADMIN') NOT NULL,
  recipient_id INT NULL, -- id sesuai recipient_type
  aduan_id INT NULL,
  pesan TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (aduan_id) REFERENCES aduan(aduan_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- INDEX yang berguna
CREATE INDEX idx_aduan_status ON aduan(status);
CREATE INDEX idx_aduan_kategori ON aduan(kategori_id);
CREATE INDEX idx_tugas_petugas ON tugas_penindakan(petugas_id);
CREATE INDEX idx_notif_recipient ON notifikasi(recipient_type, recipient_id);
