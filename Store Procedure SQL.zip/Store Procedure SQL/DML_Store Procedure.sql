-- Menambah data pelanggan
INSERT INTO pelanggan (nama, email, no_hp, alamat)
VALUES ('Andi', 'andi@gmail.com', '08123456789', 'Jakarta');

-- Menambah data produk
INSERT INTO produk (nama_produk, harga, stok)
VALUES ('Keyboard Mechanical', 550000, 10);

-- Mengubah harga produk
UPDATE produk
SET harga = 600000
WHERE id_produk = 1;

-- Menghapus produk yang tidak dijual lagi
DELETE FROM produk
WHERE id_produk = 5;
