create database pertemuan9;
use pertemuan9;

CREATE TABLE dosen (
  id_dosen INT PRIMARY KEY,
  nama_dosen VARCHAR(100) NOT NULL,
  email_dosen VARCHAR(100) UNIQUE
);

CREATE TABLE kuliah (
  id_kuliah INT PRIMARY KEY,
  nama_kuliah VARCHAR(100) NOT NULL,
  sks INT,
  id_dosen INT,
  FOREIGN KEY (id_dosen) REFERENCES dosen(id_dosen)
);

-- Isi data Tabel DOSEN
INSERT INTO dosen (id_dosen, nama_dosen, email_dosen)
VALUES
(1, 'Dr. Budi Santoso', 'budi@kampus.ac.id'),
(2, 'Dr. Lina Dewi', 'lina@kampus.ac.id');

-- Isi data Tabel KULIAH
INSERT INTO kuliah (id_kuliah, nama_kuliah, sks, id_dosen)
VALUES
(101, 'Basis Data', 3, 1),
(102, 'Algoritma dan Pemrograman', 3, 1),
(103, 'Jaringan Komputer', 2, 2);

-- Menampilkan hasil data relasi
SELECT 
  dosen.nama_dosen,
  dosen.email_dosen,
  kuliah.nama_kuliah,
  kuliah.sks
FROM kuliah
JOIN dosen ON kuliah.id_dosen = dosen.id_dosen;
