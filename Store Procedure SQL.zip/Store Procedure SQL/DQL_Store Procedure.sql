-- Menampilkan semua pelanggan
SELECT * FROM pelanggan;

-- Menampilkan produk dengan stok sedikit
SELECT * FROM produk WHERE stok < 5;

-- Menampilkan laporan transaksi
SELECT t.id_transaksi, p.nama, t.tanggal, t.total
FROM transaksi t
JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
ORDER BY t.tanggal DESC;
