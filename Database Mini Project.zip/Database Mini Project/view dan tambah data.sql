SELECT * FROM admin_pemda;
SELECT * FROM aduan;
SELECT * FROM feedback;
SELECT * FROM kategori_aduan;
SELECT * FROM lampiran;
SELECT * FROM log_status;
SELECT * FROM notifikasi;
SELECT * FROM petugas;
SELECT * FROM tugas_penindakan;
SELECT * FROM warga;


INSERT INTO kategori_aduan (nama_kategori, deskripsi) VALUES
('Sampah','Masalah pembuangan dan pengangkutan sampah'),
('Jalan Rusak','Kerusakan jalan atau infrastrukur kecil'),
('Keamanan','Keamanan lingkungan / gangguan'),
('Transportasi','Masalah transportasi umum / halte');

-- Warga sample
INSERT INTO warga (nama, email, password_hash, no_hp) VALUES
('Budi Santoso','budi@example.com','hash_demo','081234567890'),
('Siti Aminah','siti@example.com','hash_demo','081298765432');

-- Petugas sample
INSERT INTO petugas (nama, bidang, no_hp) VALUES
('Agus Saputra','kebersihan','08121234567'),
('Rina Dewi','keamanan','08123456788');

-- Admin sample (admin + manager)
INSERT INTO admin_pemda (nama, username, password_hash, role, email) VALUES
('Admin Kebersihan','adminkeb','hash_demo','ADMIN','adminkeb@bintaro.go.id'),
('Kepala Dinas','kepaladinas','hash_demo','MANAGER','kepala@bintaro.go.id');

-- Aduan sample oleh warga (1)
INSERT INTO aduan (warga_id, kategori_id, judul, deskripsi, lokasi)
VALUES (1, 1, 'Tumpukan sampah di selokan', 'Sudah 7 hari belum diangkut, bau menyengat', 'Jl. Melati - RT05');

-- Simpan lampiran untuk aduan (warga upload photo)
INSERT INTO lampiran (aduan_id, uploaded_by_type, uploaded_by_id, file_path, tipe)
VALUES (1, 'WARGA', 1, '/uploads/sampah_rt05_01.jpg', 'FOTO');