DELIMITER //
CREATE PROCEDURE update_harga_produk (
    IN p_id_produk INT,
    IN p_harga_baru DECIMAL(10,2)
)
BEGIN
    UPDATE produk
    SET harga = p_harga_baru
    WHERE id_produk = p_id_produk;
END //
DELIMITER ;

CALL update_harga_produk(1, 750000);
