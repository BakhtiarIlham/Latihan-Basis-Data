-- 1) BEFORE UPDATE: set tanggal_selesai saat status berubah menjadi SELESAI
DELIMITER $$
CREATE TRIGGER trg_aduan_before_update
BEFORE UPDATE ON aduan
FOR EACH ROW
BEGIN
  IF NEW.status = 'SELESAI' AND OLD.status <> 'SELESAI' THEN
    SET NEW.tanggal_selesai = NOW();
  END IF;
  IF NEW.status = 'DITERIMA' AND OLD.status <> 'DITERIMA' THEN
    SET NEW.tanggal_diterima = NOW();
  END IF;
END$$
DELIMITER ;

-- 2) AFTER UPDATE: catat log_status & kirim notifikasi ke warga
DELIMITER $$
CREATE TRIGGER trg_aduan_after_update
AFTER UPDATE ON aduan
FOR EACH ROW
BEGIN
  DECLARE changer_name VARCHAR(100);
  -- tentukan siapa (prioritas: admin -> petugas -> system)
  IF NEW.admin_id IS NOT NULL THEN
    SELECT nama INTO changer_name FROM admin_pemda WHERE admin_id = NEW.admin_id LIMIT 1;
  ELSEIF NEW.petugas_id IS NOT NULL THEN
    SELECT nama INTO changer_name FROM petugas WHERE petugas_id = NEW.petugas_id LIMIT 1;
  ELSE
    SET changer_name = 'SYSTEM';
  END IF;

  INSERT INTO log_status (aduan_id, status_lama, status_baru, diubah_oleh, keterangan)
  VALUES (NEW.aduan_id, OLD.status, NEW.status, COALESCE(changer_name,'SYSTEM'), CONCAT('Perubahan otomatis/berdasarkan aksi: ', NEW.status));

  -- Kirim notifikasi ke warga untuk status penting
  IF OLD.status <> NEW.status THEN
    CASE NEW.status
      WHEN 'DITERIMA' THEN
        INSERT INTO notifikasi (recipient_type, recipient_id, aduan_id, pesan)
        VALUES ('WARGA', NEW.warga_id, NEW.aduan_id, CONCAT('Aduan Anda (', NEW.judul, ') telah DITERIMA oleh admin.'));
      WHEN 'DIPROSES' THEN
        INSERT INTO notifikasi (recipient_type, recipient_id, aduan_id, pesan)
        VALUES ('WARGA', NEW.warga_id, NEW.aduan_id, CONCAT('Aduan Anda (', NEW.judul, ') sedang DIPROSES oleh petugas.'));
      WHEN 'SELESAI' THEN
        INSERT INTO notifikasi (recipient_type, recipient_id, aduan_id, pesan)
        VALUES ('WARGA', NEW.warga_id, NEW.aduan_id, CONCAT('Aduan Anda (', NEW.judul, ') sudah SELESAI. Terima kasih!'));
      ELSE
        -- untuk status lain jangan kirim notifikasi otomatis (atau tambahkan bila perlu)
        INSERT INTO notifikasi (recipient_type, recipient_id, aduan_id, pesan)
        VALUES ('WARGA', NEW.warga_id, NEW.aduan_id, CONCAT('Status aduan Anda berubah menjadi: ', NEW.status));
    END CASE;
  END IF;
END$$
DELIMITER ;

-- 3) AFTER INSERT tugas_penindakan: update aduan.petugas_id & set status -> 'DIPROSES'
DELIMITER $$
CREATE TRIGGER trg_tugas_after_insert
AFTER INSERT ON tugas_penindakan
FOR EACH ROW
BEGIN
  -- set petugas di table aduan (so aplikasi/queries mudah menemukan assignee)
  UPDATE aduan SET petugas_id = NEW.petugas_id, status = 'DIPROSES', admin_id = NEW.assigned_by WHERE aduan_id = NEW.aduan_id;
  -- notifikasi ke petugas
  INSERT INTO notifikasi (recipient_type, recipient_id, aduan_id, pesan)
  VALUES ('PETUGAS', NEW.petugas_id, NEW.aduan_id, CONCAT('Anda mendapat tugas baru: aduan_id=', NEW.aduan_id));
END$$
DELIMITER ;